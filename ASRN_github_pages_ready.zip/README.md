# ASRN

This is the **ASRN** website, ready for GitHub Pages deployment.

## How to publish on GitHub Pages

1. Create a new repository on GitHub named **ASRN** (or any name you like).
2. Upload all files from this folder into the root of your repository.
3. Commit and push changes.
4. Go to **Settings → Pages**.
5. Under **Branch**, select `main` (or `master`) and folder `/root`, then click **Save**.
6. Your site will be live at:

```
https://<your-github-username>.github.io/<repository-name>/
```

Replace `<your-github-username>` with your GitHub username.

---
**Note:** GitHub Pages is case-sensitive for file names. The main entry file is `index.html`.
